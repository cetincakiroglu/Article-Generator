import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';


ReactDOM.render(
   <App className="d-flex flex-column "/>,
  document.getElementById('root')
);


